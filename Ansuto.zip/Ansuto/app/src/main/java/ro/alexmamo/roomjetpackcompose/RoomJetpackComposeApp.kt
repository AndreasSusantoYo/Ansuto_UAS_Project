package ro.alexmamo.roomjetpackcompose

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoomJetpackComposeApp : Application()